import pandas as pd
from sqlalchemy import create_engine, text
from etl_pipeline.db_config import DB_CONFIG

MYSQL_URL = f"mysql+pymysql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
engine = create_engine(MYSQL_URL, echo=False, pool_pre_ping=True)

def clear_all_tables():
    """Clear all tables in reverse dependency order to prevent foreign key violations"""
    print("Clearing existing data...")
    
    tables_to_clear = [
        "fact_student_performance",
        "fact_student_lifestyle", 
        "dim_academic_support",
        "dim_parent_details",
        "dim_subject",
        "dim_student"
    ]
    
    with engine.begin() as conn:
        for table in tables_to_clear:
            conn.execute(text(f"DELETE FROM {table}"))
            print(f"Cleared {table}")

def load_table(df, table_name):
    """Load data into table with proper deduplication for dimensions"""
    if df.empty:
        print(f"No data to insert into {table_name}")
        return 0

    # Ensure dimensions are deduplicated
    if table_name.startswith("dim_"):
        original_count = len(df)
        df = df.drop_duplicates()
        if len(df) < original_count:
            print(f"Deduplicated {table_name}: {original_count} -> {len(df)} rows")

    # Load data
    df.to_sql(
        table_name,
        engine,
        if_exists="append",
        index=False,
        method="multi"
    )
    
    print(f"Loaded {len(df)} rows into {table_name}")
    return len(df)

def fetch_dimension(table_name):
    """Fetch dimension data for foreign key mapping"""
    return pd.read_sql(f"SELECT * FROM {table_name}", engine)

def load_fact_student_performance(df):
    """Load performance fact with proper foreign key resolution"""
    print("Loading fact_student_performance...")
    
    # Get dimension tables for foreign key mapping
    students = fetch_dimension("dim_student")
    subjects = fetch_dimension("dim_subject")
    parents = fetch_dimension("dim_parent_details")
    academic_support = fetch_dimension("dim_academic_support")
    
    # Create foreign key mappings
    student_map = students.set_index([
        'school', 'sex', 'age', 'address', 'family_size', 'parent_cohabitation_status', 'guardian'
    ])['student_id'].to_dict()
    
    subject_map = subjects.set_index('subject_name')['subject_id'].to_dict()
    
    parent_map = parents.set_index([
        'mother_education_level', 'father_education_level', 'mother_job_title', 'father_job_title'
    ])['parent_details_id'].to_dict()
    
    academic_map = academic_support.set_index([
        'school_choice_reason', 'school_support', 'family_support', 'extra_paid_classes'
    ])['academic_support_id'].to_dict()
    
    # Map foreign keys
    df['student_id'] = df.apply(
        lambda row: student_map.get(
            (row['school'], row['sex'], row['age'], row['address'], 
             row['family_size'], row['parent_cohabitation_status'], row['guardian'])
        ), axis=1
    )
    
    df['subject_id'] = df['subject_name'].map(subject_map)
    df['parent_details_id'] = df.apply(
        lambda row: parent_map.get(
            (row['mother_education_level'], row['father_education_level'], 
             row['mother_job_title'], row['father_job_title'])
        ), axis=1
    )
    df['academic_support_id'] = df.apply(
        lambda row: academic_map.get(
            (row['school_choice_reason'], row['school_support'], 
             row['family_support'], row['extra_paid_classes'])
        ), axis=1
    )
    
    # Check for missing foreign keys
    missing_fks = df[['student_id', 'subject_id']].isnull().any()
    if missing_fks.any():
        print("ERROR: Missing foreign keys in performance fact!")
        print(f"Missing student_id: {df['student_id'].isnull().sum()}")
        print(f"Missing subject_id: {df['subject_id'].isnull().sum()}")
        raise ValueError("Foreign key resolution failed")
    
    # Select only fact table columns
    fact_cols = [
        'student_id', 'subject_id', 'parent_details_id', 'academic_support_id',
        'first_period_grade', 'second_period_grade', 'final_grade',
        'prior_class_failures', 'total_absences', 
        'weekly_study_time_category', 'commute_time_category'
    ]
    
    fact_df = df[fact_cols].copy()
    return load_table(fact_df, "fact_student_performance")

def load_fact_student_lifestyle(df):
    """Load lifestyle fact with proper foreign key resolution"""
    print("Loading fact_student_lifestyle...")
    
    # Get student dimension for foreign key mapping
    students = fetch_dimension("dim_student")
    
    # Create student foreign key mapping
    student_map = students.set_index([
        'school', 'sex', 'age', 'address', 'family_size', 'parent_cohabitation_status', 'guardian'
    ])['student_id'].to_dict()
    
    # Map student foreign key
    df['student_id'] = df.apply(
        lambda row: student_map.get(
            (row['school'], row['sex'], row['age'], row['address'], 
             row['family_size'], row['parent_cohabitation_status'], row['guardian'])
        ), axis=1
    )
    
    # Check for missing foreign keys
    if df['student_id'].isnull().any():
        print("ERROR: Missing student_id in lifestyle fact!")
        print(f"Missing student_id: {df['student_id'].isnull().sum()}")
        raise ValueError("Foreign key resolution failed")
    
    # Select only fact table columns
    fact_cols = [
        'student_id',
        'extracurricular_activities', 'attended_nursery_school', 
        'plans_higher_education', 'internet_access', 'romantic_relationship',
        'family_relationship_quality_score', 'free_time_index', 
        'social_activity_index', 'weekday_alcohol_consumption_level',
        'weekend_alcohol_consumption_level', 'health_status_score'
    ]
    
    fact_df = df[fact_cols].copy()
    return load_table(fact_df, "fact_student_lifestyle")

def get_table_counts():
    """Get row counts for all tables"""
    counts = {}
    tables = [
        "dim_student", "dim_subject", "dim_parent_details", 
        "dim_academic_support", "fact_student_lifestyle", "fact_student_performance"
    ]
    
    for table in tables:
        try:
            result = pd.read_sql(f"SELECT COUNT(*) as count FROM {table}", engine)
            counts[table] = result['count'].iloc[0]
        except Exception as e:
            counts[table] = f"Error: {e}"
    
    return counts
