import pandas as pd

def transform_data(raw_df):
    df = raw_df.copy()

    # Normalize column names
    df.columns = df.columns.str.strip().str.lower()

    # Handle boolean columns for merged dataset
    BOOLEAN_COLS = [
        "schoolsup.x", "famsup.x", "paid.x", "activities.x",
        "nursery", "higher.x", "internet", "romantic.x"
    ]

    for col in BOOLEAN_COLS:
        if col in df.columns:
            df[col] = (
                df[col]
                .astype(str)
                .str.lower()
                .map({"yes": True, "no": False})
                .fillna(False)
            )

    return df

def build_dim_student(df):
    """Build student dimension with proper field names and deduplication"""
    # Handle quoted column names and actual structure
    cols = []
    
    # Find the correct column names (some may be quoted)
    for expected_col in ["school", "sex", "age", "address", "famsize", "pstatus", "guardian"]:
        found_col = None
        for col in df.columns:
            # Remove quotes and check if it matches expected
            clean_col = col.replace('"', '').strip()
            if clean_col.lower() == expected_col.lower():
                found_col = col
                break
        
        if found_col:
            cols.append(found_col)
        else:
            print(f"Warning: Column '{expected_col}' not found in dataset")
    
    if not cols:
        print("Available columns:", df.columns.tolist())
        raise ValueError("Required student columns not found in dataset")
    
    student_df = df[cols].copy()
    
    # Rename columns to match database schema
    student_df.columns = [
        'school', 'sex', 'age', 'address', 'famsize', 'pstatus', 'guardian'
    ]
    
    # Rename columns to match database schema
    student_df = student_df.rename(columns={
        'famsize': 'family_size',
        'pstatus': 'parent_cohabitation_status'
    })
    
    # Ensure deduplication
    return student_df.drop_duplicates().reset_index(drop=True)

def build_dim_subject(df):
    """Create subject dimension with Math and Portuguese"""
    subjects = pd.DataFrame({
        "subject_name": ["Math", "Portuguese"]
    })
    return subjects

def build_dim_parent_details(df):
    """Build parent details dimension with proper field names and deduplication"""
    # Handle quoted column names and actual structure
    cols = []
    expected_cols = ["medu", "fedu", "mjob", "fjob"]
    
    for expected_col in expected_cols:
        found_col = None
        for col in df.columns:
            clean_col = col.replace('"', '').strip()
            if clean_col.lower() == expected_col.lower():
                found_col = col
                break
        
        if found_col:
            cols.append(found_col)
        else:
            print(f"Warning: Column '{expected_col}' not found in dataset")
    
    parent_df = df[cols].copy()
    
    # Rename columns to match database schema
    parent_df.columns = ['medu', 'fedu', 'mjob', 'fjob']
    parent_df = parent_df.rename(columns={
        'medu': 'mother_education_level',
        'fedu': 'father_education_level',
        'mjob': 'mother_job_title',
        'fjob': 'father_job_title'
    })
    
    # Ensure deduplication
    return parent_df.drop_duplicates().reset_index(drop=True)

def build_dim_academic_support(df):
    """Build academic support dimension with proper field names and deduplication"""
    # Handle quoted column names and actual structure
    cols = []
    expected_cols = ["reason", "schoolsup.x", "famsup.x", "paid.x"]
    
    for expected_col in expected_cols:
        found_col = None
        for col in df.columns:
            clean_col = col.replace('"', '').strip()
            if clean_col.lower() == expected_col.lower():
                found_col = col
                break
        
        if found_col:
            cols.append(found_col)
        else:
            print(f"Warning: Column '{expected_col}' not found in dataset")
    
    academic_df = df[cols].copy()
    
    # Rename columns to match database schema
    academic_df.columns = ['reason', 'schoolsup.x', 'famsup.x', 'paid.x']
    academic_df = academic_df.rename(columns={
        'schoolsup.x': 'school_support',
        'famsup.x': 'family_support',
        'paid.x': 'extra_paid_classes',
        'reason': 'school_choice_reason'
    })
    
    # Ensure deduplication
    return academic_df.drop_duplicates().reset_index(drop=True)

def build_fact_student_performance(df):
    """Transform .x and .y columns into separate rows for each subject"""
    performance_rows = []
    
    # Helper function to find column name
    def find_column(expected_name):
        for col in df.columns:
            clean_col = col.replace('"', '').strip()
            if clean_col.lower() == expected_name.lower():
                return col
        return None
    
    for _, row in df.iterrows():
        # Math subject record (.x columns)
        math_row = {
            "school": row[find_column("school")],
            "sex": row[find_column("sex")], 
            "age": row[find_column("age")],
            "address": row[find_column("address")],
            "famsize": row[find_column("famsize")],
            "pstatus": row[find_column("pstatus")],
            "guardian": row[find_column("guardian")],
            "subject_name": "Math",
            
            "mother_education_level": row[find_column("medu")],
            "father_education_level": row[find_column("fedu")], 
            "mother_job_title": row[find_column("mjob")],
            "father_job_title": row[find_column("fjob")],
            
            "school_choice_reason": row[find_column("reason")],
            "school_support": row[find_column("schoolsup.x")],
            "family_support": row[find_column("famsup.x")],
            "extra_paid_classes": row[find_column("paid.x")],
            
            "prior_class_failures": row[find_column("failures.x")],
            "total_absences": row[find_column("absences.x")],
            "weekly_study_time_category": row[find_column("studytime.x")],
            "commute_time_category": row[find_column("traveltime.x")],
            
            "first_period_grade": row[find_column("g1.x")],
            "second_period_grade": row[find_column("g2.x")], 
            "final_grade": row[find_column("g3.x")]
        }
        performance_rows.append(math_row)
        
        # Portuguese subject record (.y columns)
        port_row = {
            "school": row[find_column("school")],
            "sex": row[find_column("sex")],
            "age": row[find_column("age")], 
            "address": row[find_column("address")],
            "famsize": row[find_column("famsize")],
            "pstatus": row[find_column("pstatus")],
            "guardian": row[find_column("guardian")],
            "subject_name": "Portuguese",
            
            "mother_education_level": row[find_column("medu")],
            "father_education_level": row[find_column("fedu")],
            "mother_job_title": row[find_column("mjob")],
            "father_job_title": row[find_column("fjob")],
            
            "school_choice_reason": row[find_column("reason")],
            "school_support": row[find_column("schoolsup.x")],
            "family_support": row[find_column("famsup.x")],
            "extra_paid_classes": row[find_column("paid.x")],
            
            "prior_class_failures": row[find_column("failures.y")],
            "total_absences": row[find_column("absences.y")],
            "weekly_study_time_category": row[find_column("studytime.y")],
            "commute_time_category": row[find_column("traveltime.y")],
            
            "first_period_grade": row[find_column("g1.y")],
            "second_period_grade": row[find_column("g2.y")],
            "final_grade": row[find_column("g3.y")]
        }
        performance_rows.append(port_row)
    
    performance_df = pd.DataFrame(performance_rows)
    
    # Verify grain: should be 2 rows per student
    expected_rows = len(df) * 2
    if len(performance_df) != expected_rows:
        print(f"WARNING: Expected {expected_rows} performance rows, got {len(performance_df)}")
    
    return performance_df

def build_fact_student_lifestyle(df):
    """Build lifestyle fact with proper field names"""
    # Helper function to find column name
    def find_column(expected_name):
        for col in df.columns:
            clean_col = col.replace('"', '').strip()
            if clean_col.lower() == expected_name.lower():
                return col
        return None
    
    # Map merged dataset columns to lifestyle fact
    lifestyle_df = pd.DataFrame()
    lifestyle_df["school"] = df[find_column("school")]
    lifestyle_df["sex"] = df[find_column("sex")]
    lifestyle_df["age"] = df[find_column("age")]
    lifestyle_df["address"] = df[find_column("address")]
    lifestyle_df["famsize"] = df[find_column("famsize")]
    lifestyle_df["pstatus"] = df[find_column("pstatus")]
    lifestyle_df["guardian"] = df[find_column("guardian")]
    
    lifestyle_df["commute_time_category"] = df[find_column("traveltime.x")]
    lifestyle_df["weekly_study_time_category"] = df[find_column("studytime.x")]
    
    lifestyle_df["extracurricular_activities"] = df[find_column("activities.x")]
    lifestyle_df["attended_nursery_school"] = df[find_column("nursery")]
    lifestyle_df["plans_higher_education"] = df[find_column("higher.x")]
    lifestyle_df["internet_access"] = df[find_column("internet")]
    lifestyle_df["romantic_relationship"] = df[find_column("romantic.x")]
    
    lifestyle_df["family_relationship_quality_score"] = df[find_column("famrel.x")]
    lifestyle_df["free_time_index"] = df[find_column("freetime.x")]
    lifestyle_df["social_activity_index"] = df[find_column("goout.x")]
    lifestyle_df["weekday_alcohol_consumption_level"] = df[find_column("dalc.x")]
    lifestyle_df["weekend_alcohol_consumption_level"] = df[find_column("walc.x")]
    lifestyle_df["health_status_score"] = df[find_column("health.x")]
    
    return lifestyle_df.drop_duplicates().reset_index(drop=True)
